#!/bin/bash

echo "🔧 INH Kurulumu Başlatılıyor..."

# 1. Gerekli dizinleri tanımla
INSTALL_DIR="$HOME/.inh"
BIN_FILE="/usr/local/bin/inh"

# 2. Projeyi ~/.inh içine kopyala
mkdir -p "$INSTALL_DIR"
cp -r ./* "$INSTALL_DIR"

# 3. Çalıştırılabilir symlink oluştur
echo "📦 Uygulama dizine taşındı: $INSTALL_DIR"
echo "🔗 Sembolik bağlantı oluşturuluyor: $BIN_FILE"

# Global çalıştırmak için sembolik bağlantı
sudo ln -sf "$INSTALL_DIR/cli.js" "$BIN_FILE"

# 4. Çalıştırılabilir izin ver
chmod +x "$INSTALL_DIR/cli.js"

# 5. Kontrol et
if command -v inh &> /dev/null; then
  echo "✅ Kurulum tamamlandı. 'inh' komutu artık kullanılabilir!"
  inh help
else
  echo "⚠️ Kurulum tamamlandı ama 'inh' komutu bulunamıyor."
  echo "Lütfen PATH ayarlarınızı kontrol edin veya terminali yeniden başlatın."
fi
