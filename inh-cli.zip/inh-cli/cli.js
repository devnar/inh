#!/usr/bin/env node

import { Command } from 'commander';
import axios from 'axios';
import unzipper from 'unzipper';
import fs from 'fs-extra';
import path from 'path';
import { execSync } from 'child_process';
import { pathToFileURL } from 'url';

const program = new Command();
const INH_DIR = path.join(process.env.HOME || process.env.USERPROFILE, '.inh');
const PKG_DIR = path.join(INH_DIR, 'packages');

fs.ensureDirSync(PKG_DIR);

const API_BASE = 'https://inh.onrender.com/api';


function runPackage(name) {
  const pkgPath = path.join(PKG_DIR, name);
  const meta = JSON.parse(fs.readFileSync(path.join(pkgPath, 'inh.json')));
  const entry = path.join(pkgPath, meta.entry);

  try {
    const entryUrl = pathToFileURL(entry).href;
    import(entryUrl)
      .then(() => {
        console.log(`Paket ${name} başarıyla çalıştırıldı.`);
      })
      .catch(err => {
        console.error(`\n[!] Paket çalıştırılırken hata oluştu:`, err);
      });
  } catch (err) {
    console.error(`\n[!] Paket çalıştırılırken hata oluştu:`, err);
  }
}

// inh 
program
  .name('inh')
  .description(`Welcome to \"I'm Not Hacker Terminal\"! This is an open-source development platform designed as a web terminal, enabling developers and enthusiasts to create and enhance their own terminal experience by writing JavaScript code.`)
  .version('1.0.0');

// Komut: inh install <paket>
program
  .command('install <name>')
  .alias('i') 
  .description('Bir paketi indir ve kur')
  .action(async (name) => {
    const res = await axios.get(`${API_BASE}/packages/${name}`);
    const pkg = res.data;

    const zipUrl = `${pkg.repo}/archive/refs/heads/main.zip`;
    const targetPath = path.join(PKG_DIR, name);

    console.log(`[+] ${name} paketi indiriliyor...`);
    const zipRes = await axios({ url: zipUrl, responseType: 'stream' });

    await fs.emptyDir(targetPath);
    await new Promise((resolve, reject) => {
      zipRes.data
        .pipe(unzipper.Extract({ path: targetPath }))
        .on('close', resolve)
        .on('error', reject);
    });

    // iç içe klasör varsa düzleştir
    const subDirs = await fs.readdir(targetPath);
    if (subDirs.length === 1) {
      const inner = path.join(targetPath, subDirs[0]);
      await fs.copy(inner, targetPath);
      await fs.remove(inner);
    }

    // npm install (varsa package.json)
    if (fs.existsSync(path.join(targetPath, 'package.json'))) {
      console.log('[+] Bağımlılıklar kuruluyor...');
      execSync('npm install', { cwd: targetPath, stdio: 'inherit' });
    }

    console.log(`[✓] ${name} başarıyla kuruldu.`);
  });

// Komut: inh run <paket>
program
  .command('run <name>')
  .description('Kurulu bir paketi çalıştır')
  .action(runPackage);

// Komut: inh uninstall <paket>
program
  .command('uninstall <name>')
  .alias('u') 
  .description('Paketi sil')
  .action((name) => {
    const target = path.join(PKG_DIR, name);
    if (fs.existsSync(target)) {
      fs.removeSync(target);
      console.log(`[✓] ${name} kaldırıldı.`);
    } else {
      console.log(`[!] ${name} yüklü değil.`);
    }
  });

// Komut: inh list
program
  .command('list')
  .description('Yüklü paketleri göster')
  .action(() => {
    const dirs = fs.readdirSync(PKG_DIR);
    if (dirs.length === 0) return console.log('Hiç paket yüklenmemiş.');
    console.log('Yüklü paketler:');
    dirs.forEach(d => console.log(`- ${d}`));
  });

program.parse();
